import Head from 'next/head'
import React from 'react'

export default function account() {
  return (
    <>
    <Head>
    <title>Beer World | Account</title>
    </Head>
    

    <div>my account will be here</div>
    </>
  )
}
