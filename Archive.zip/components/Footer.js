import React from 'react'


export const Footer = () => {
  return (
    <footer>@Copyright 2023 All rights reserved</footer>
  )
}

